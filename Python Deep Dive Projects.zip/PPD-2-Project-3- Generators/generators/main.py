from collections import namedtuple
from datetime import datetime
from collections import defaultdict

file = 'nyc_parking_tickets_extract.csv'


def clean_data(filename):
    with open(filename) as f:
        for line in f:
            yield line.strip('\n').split(',')


# def clean_data(filename):
#     yield from clean_data(filename)


def data_to_tuple(filename):
    di = clean_data(filename)
    headers = next(di)
    for i in range(len(headers)):
        headers[i] = headers[i].replace(' ', '_')
    Data_tuple = namedtuple('Data_tuple', headers)
    for line in di:
        yield Data_tuple(int(line[0]), line[1], line[2], line[3], datetime.strptime(line[4], '%m/%d/%Y'), int(line[5]),
                         line[6], line[7], line[8])


dt = data_to_tuple(file)
violations_by_car_make = defaultdict(int)
for entry in dt:
    violations_by_car_make[entry.Vehicle_Make] += 1

# print(violations_by_car_make)
violations_by_car_make = {make: count for make, count in sorted(violations_by_car_make.items(), key=lambda x: x[1], reverse=True)}
print(violations_by_car_make)
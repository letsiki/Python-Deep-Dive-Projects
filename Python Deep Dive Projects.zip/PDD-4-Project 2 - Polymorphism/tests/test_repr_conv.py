import pytest
import os
import sys
from copy import copy
sys.path.append(os.getcwd())
from src.mod import Mod

def test_repr(this_mod):
    assert repr(this_mod) == 'Mod(2, 3)'
    

def test_str(other_mod):
    assert str(other_mod) == 'Mod(1, 3)'

def test_int_success(this_mod):
    assert int(this_mod) == 2

def test_int_failure(other_mod):
    assert not (int(other_mod) == 2)

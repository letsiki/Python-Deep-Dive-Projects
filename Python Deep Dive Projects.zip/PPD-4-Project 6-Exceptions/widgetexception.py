from http import HTTPStatus
import json

class WidgetException(Exception):
    "level 1 exception for the widget online sales application"

    http_status = HTTPStatus.INTERNAL_SERVER_ERROR
    internal_error_message = 'API Exception Occurred'
    user_error_message = 'An error has Occurred on our end'

    def __init__(self, *args, user_error_message=None):
        if args:
            self.internal_error_message = args[0]
            super().__init__(args)
        else:
            super().__init__(self.internal_error_message)

        if user_error_message is not None:
            self.user_error_message = user_error_message

    def to_json(self):
        error_obj = {"status": self.http_status, "message": self.user_error_message}
        return json.dumps(error_obj)
    
    def log_exception(self):
        exception = {
            "type": type(self).__qualname__,
            "http status": self.http_status,
            "message": self.internal_error_message
        }
        return exception

class SupplierException(WidgetException):
    "level 2 exception for all supplier exceptions"

class CheckoutException(WidgetException):
    "level 2 exception for all checkout exceptions"

class NotManufacturedException(SupplierException):
    "level 3 supplier exception for no longer manufactured widgets"

class ProductionDelayedException(SupplierException):
    "level 3 supplier exception for delayed production"

class ShippingDelayedException(SupplierException):
    "level 3 supplier exdeption for delayed shipping"

class InventoryExceptions(CheckoutException):
    "level 3 checkout exception, for all exceptions of inventory type"

class PricingException(CheckoutException):
    "level 3 checkout exception, for all exceptions of pricing type"

class OutOfStockException(InventoryExceptions):
    "level 4 checkout-inventory exception for widgets that are out of stock"

class InvalidCouponException(PricingException):
    "level 4 checkout-pricing exceptions for invalid coupon codes"

class CouponStackException(PricingException):
    "level 4 checkout-pricing exception for stacking multiple coupons in the same order"

    http_status = HTTPStatus.BAD_REQUEST

ex = WidgetException()
print(type(ex).__qualname__)


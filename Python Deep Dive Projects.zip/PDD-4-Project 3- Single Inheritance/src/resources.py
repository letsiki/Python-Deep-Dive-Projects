class Resource:
    def __init__(self, name: str, manufacturer: str, total: int=0) -> None:
        if not isinstance(name, str):
            raise TypeError('Name must be a string')
        if not isinstance(manufacturer, str):
            raise TypeError('Manufacturer must be a string')
        self._name = name
        self._manufacturer = manufacturer
        self.check_valid_quantity_input(total, value_desc='total quantity', allow_zero=True)
        self._total = total
        self._allocated = 0

    # Getters

    @property
    def name(self) -> str:
        return self._name
    
    @property
    def manufacturer(self) -> str:
        return self._manufacturer
    
    @property
    def total(self) -> int:
        return self._total
    
    @property
    def allocated(self) -> int:
        return self._allocated
    
    # Representation

    def __str__(self) -> str:
        return self._name
    
    def __repr__(self) -> str:
        return f'{self.__class__.__name__}({self._name}, {self._manufacturer}, total={self._total}, allocated={self._allocated})'
    
    # Computed Properties

    @property
    def category(self) -> str:
        return self.__class__.__name__.lower()
    
    @property
    def available(self) -> int:
        return self._total - self._allocated
    
    # Private Methods

    @staticmethod
    def check_valid_quantity_input(n: int, *, value_desc: str='quantity', allow_zero: bool=False) -> True:
        "will raise exception if falsy"
        if not isinstance(n, int):
            raise TypeError(f'Please enter a integer value for {value_desc}')
        elif n < 0 or (n == 0 and allow_zero==False):
            raise ValueError(f'Please enter a positive value for {value_desc}')
        else:
            return True
    
    # Public Methods

    def claim(self, n: int) -> None:
        self.check_valid_quantity_input(n, value_desc='quantity claimed')
        if n > self.available:
            raise ValueError('Insufficient Quantity to claim')
        else:
            self._allocated += n

    def freeup(self, n: int) -> None:
        self.check_valid_quantity_input(n, value_desc='quantity to free up')
        if n > self._allocated:
            raise ValueError('Insufficient Quantity to free up')
        else:
            self._allocated -= n

    def died(self, n: int) -> None:
        self.check_valid_quantity_input(n, value_desc='quantity to retire')
        if n > self._allocated:
            raise ValueError('Insufficient Quantity to retire')
        else:
            self._allocated -= n
            self._total -= n
            
    def purchased(self, n: int) -> None:
        self.check_valid_quantity_input(n, value_desc='quantity to purchase')
        self._total += n

class Storage(Resource):
    def __init__(self, name: str, manufacturer: str, total: int=0, *, capacity_GB: int) -> None:
        super().__init__(name, manufacturer, total)
        self.check_valid_quantity_input(capacity_GB, value_desc='capacity')
        self._capacity_GB = capacity_GB

    # Getters
    
    @property
    def capacity_GB(self) -> int:
        return self._capacity_GB
    
    # Representation

    def __repr__(self):
        return super().__repr__()[:-1] + f', capacity_GB={self._capacity_GB})'

class SSD(Storage):
    def __init__(self, name: str, manufacturer: str, total: int=0, *, capacity_GB: int, interface: str) -> None:
        super().__init__(name, manufacturer, total, capacity_GB=capacity_GB)
        if isinstance(interface, str):
            self._interface = interface
        else:
            raise TypeError('SSD interface must be a string')

    # Getters
    
    @property
    def interface(self) -> int:
        return self._interface
    
    # Representation

    def __repr__(self):
        return super().__repr__()[:-1] + f', interface={self._interface})'

class HDD(Storage):
    def __init__(self, name: str, manufacturer: str, total: int=0, *, capacity_GB: int, size: str, rpm: int) -> None:
        super().__init__(name, manufacturer, total, capacity_GB=capacity_GB)
        self.check_valid_quantity_input(rpm, value_desc='rpm')
        self._rpm = rpm
        if isinstance(size, str):
            self._size = size
        else:
            raise TypeError('HDD form factor must be a string')

    # Getters
    
    @property
    def size(self) -> int:
        return self._size
    
    @property
    def rpm(self) -> int:
        return self._rpm
    
    # Representation

    def __repr__(self):
        return super().__repr__()[:-1] + f', size={self._size}, rpm={self._rpm})'

class CPU(Resource):
    def __init__(self, name: str, manufacturer: str, total: int=0, *, cores: int, socket: str, power_watts: int) -> None:
        super().__init__(name, manufacturer, total)
        if not isinstance(socket, str):
            raise TypeError('socket must be a string')
        self._socket = socket
        self.check_valid_quantity_input(cores, value_desc='cores quantity')
        self._cores = cores
        self.check_valid_quantity_input(power_watts, value_desc='watts')
        self._power_watts = power_watts

    # Getters
        
    @property
    def socket(self):
        return self._socket
    
    @property
    def cores(self):
        return self._cores
    
    @property
    def power_watts(self):
        return self._power_watts
        
    # Representation

    def __repr__(self):
        return super().__repr__()[:-1] + f', cores={self._cores}, socket={self._socket}, power_watts={self._power_watts})'
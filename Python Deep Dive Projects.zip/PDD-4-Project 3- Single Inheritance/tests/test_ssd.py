# TODO: complete conversion from storage to ssd

import pytest
import os
import sys
sys.path.append(os.getcwd())
from src.resources import SSD

def test_init_success():
    ssd1 = SSD('asd','aaa', 3, capacity_GB=128, interface='asd')
    assert ssd1._allocated == 0
    assert ssd1.capacity_GB == 128
    assert ssd1._manufacturer == 'aaa'
    assert ssd1._name == 'asd'
    assert ssd1._total == 3
    assert ssd1._interface == 'asd'

parameter_list_type_error = [
    (123, 'amd', 3, 3, 'asd'),
    ('i3-234', 123, 4, 4, 'asd'),
    ('ryzen 2344', 'amd', '123', 5, 'asd'),
    ('snapdragon-554', 'qualcomm', 3, '33', 'asd'),
    ('snapdragon-554', 'qualcomm', 3, 33, 123)
]

@pytest.mark.parametrize('name, manufacturer, total, capacity_GB, interface', parameter_list_type_error)
def test_init_type_error(name, manufacturer, total, capacity_GB, interface):
    with pytest.raises(TypeError):
        SSD(name, manufacturer, total, capacity_GB=capacity_GB, interface=interface)

parameter_list_value_error = [
    ('123', 'amd', -1, 1, 'asd'),
    ('i3-234', '123', 4, 0, 'asd')
]

@pytest.mark.parametrize('name, manufacturer, total, capacity_GB, interface', parameter_list_value_error)
def test_init_value_error(name, manufacturer, total, capacity_GB, interface):
    with pytest.raises(ValueError):
        SSD(name, manufacturer, total, capacity_GB=capacity_GB, interface=interface)

def test_getters(ssd1: pytest.FixtureDef[SSD]):
    assert ssd1.name == 'generic hard disk'
    assert ssd1.manufacturer == 'oem'
    assert ssd1.total == 5
    assert ssd1.allocated == 0
    assert ssd1.capacity_GB == 128 
    assert ssd1.interface == 'nvMe 1.32'


def test_repr(ssd1: pytest.FixtureDef[SSD]):
    assert repr(ssd1) == 'SSD(generic hard disk, oem, total=5, allocated=0, capacity_GB=128, interface=nvMe 1.32)'

if __name__ == "__main__":
    pytest.main(['./tests/test_ssd.py'])
from polygon import Polygon, test_polygon
from polygons import Polygons

test_polygon()
polys = Polygons(6, 13)

# for poly in polys:
#     print(poly)

print(polys.max_efficiency_polygon)
print(polys.max_efficiency_polygon)
print(polys.max_efficiency_polygon)
print(polys.max_efficiency_polygon)
help(Polygon(334, 45))

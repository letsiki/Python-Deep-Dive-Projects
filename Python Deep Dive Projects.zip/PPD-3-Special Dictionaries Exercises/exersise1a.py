d1 = {'python': 10, 'java': 3, 'c#': 8, 'javascript': 15}
d2 = {'java': 10, 'c++': 10, 'c#': 4, 'go': 9, 'python': 6}
d3 = {'erlang': 5, 'haskell': 2, 'python': 1, 'pascal': 1}
all_dicts = [d1, d2, d3]

from collections import defaultdict
my_dict = defaultdict(int)
for d in all_dicts:
    for k, v in d.items():
        my_dict[k] += v

my_dict = {k: my_dict[k] for k in sorted(my_dict, key=lambda x:my_dict[x], reverse=True)}

print(my_dict)



# d = {'python': 17,
#      'javascript': 15,
#      'java': 13,
#      'c#': 12,
#      'c++': 10,
#      'go': 9,
#      'erlang': 5,
#      'haskell': 2,
#      'pascal': 1}

# d = {'python': 16,
#      'javascript': 15,
#      'java': 13,
#      'c#': 12,
#      'c++': 10, 
#      'go': 9}

from math import pi, sin, cos


class Polygon:

    def __init__(self, nr_edges, c_radius):
        if nr_edges < 3:
            raise ValueError('a Polygon cannot have less than 3 sides')
        self._n = nr_edges
        #self.vertices = nr_edges
        self._r = c_radius
        #self.int_angle = (self.vertices - 2) * 180 / self.vertices
        #self.edge_ln = 2 * c_radius * sin(pi / self.vertices)
        #self. apothem = c_radius * cos(pi / self.vertices)
        #self.area = (self.vertices * self.edge_ln * self.apothem) / 2
        #self.perimeter = self.edge_ln * self.vertices

    @property
    def count_vertices(self):
        return self._n

    @property
    def count_edges(self):
        return self._n

    @property
    def circumradius(self):
        return self._r

    @property
    def interior_angle(self):
        return (self._n - 2) * 180 / self._n

    @property
    def side_length(self):
        return 2 * self._r * sin(pi / self._n)

    @property
    def apothem(self):
        return self._r * cos(pi / self._n)

    @property
    def area(self):
        return (self._n * self.side_length * self.apothem) / 2

    @property
    def perimeter(self):
        return self.side_length * self._n

    def __repr__(self):
        return f'Polygon(n={self._n}, R={self._r})'

    def __eq__(self, other):
        if isinstance(other, Polygon):
            return self._n == other._n and self._r == other._r
        else:
            return NotImplemented

    def __gt__(self, other):
        if isinstance(other, Polygon):
            return self._n > other._n
        else:
            return NotImplemented

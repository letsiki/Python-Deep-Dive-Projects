import pytest
import os
import sys
sys.path.append(os.getcwd())
from src.resources import Storage

def test_init_success():
    storage1 = Storage('asd','aaa', 3, capacity_GB=128)
    assert storage1._allocated == 0
    assert storage1.capacity_GB == 128
    assert storage1._manufacturer == 'aaa'
    assert storage1._name == 'asd'
    assert storage1._total == 3

parameter_list_type_error = [
    (123, 'amd', 3, 3),
    ('i3-234', 123, 4, 4),
    ('ryzen 2344', 'amd', '123', 5),
    ('snapdragon-554', 'qualcomm', 3, '33')
]

@pytest.mark.parametrize('name, manufacturer, total, capacity_GB', parameter_list_type_error)
def test_init_type_error(name, manufacturer, total, capacity_GB):
    with pytest.raises(TypeError):
        Storage(name, manufacturer, total, capacity_GB=capacity_GB)

parameter_list_value_error = [
    ('123', 'amd', -1, 1),
    ('i3-234', '123', 4, 0)
]

@pytest.mark.parametrize('name, manufacturer, total, capacity_GB', parameter_list_value_error)
def test_init_value_error(name, manufacturer, total, capacity_GB):
    with pytest.raises(ValueError):
        Storage(name, manufacturer, total, capacity_GB=capacity_GB)

def test_getters(storage1: pytest.FixtureDef[Storage]):
    assert storage1.name == 'generic hard disk'
    assert storage1.manufacturer == 'oem'
    assert storage1.total == 5
    assert storage1.allocated == 0
    assert storage1.capacity_GB == 128 


def test_repr(storage1: pytest.FixtureDef[Storage]):
    assert repr(storage1) == 'Storage(generic hard disk, oem, total=5, allocated=0, capacity_GB=128)'

if __name__ == "__main__":
    pytest.main(['./tests/test_storage.py'])
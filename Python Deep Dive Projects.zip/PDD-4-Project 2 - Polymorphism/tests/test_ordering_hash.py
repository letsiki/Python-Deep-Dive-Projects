import pytest
import os
import sys
from copy import copy
sys.path.append(os.getcwd())
from src.mod import Mod

# Test Equality

def test_eq_true(this_mod):
    assert this_mod == copy(this_mod)
    assert this_mod == 2

def test_eq_false(this_mod, other_mod):
    assert this_mod != other_mod
    assert this_mod != 1

def test_eq_invalid(this_mod, invalid_op_mod):
    with pytest.raises(TypeError):
        assert this_mod == invalid_op_mod

# Test Less Than

def test_lt_true(this_mod, other_mod):
    assert other_mod < this_mod
    assert this_mod < 5

def test_lt_false(this_mod, other_mod):
    assert not (this_mod < other_mod)
    assert not (this_mod < -1)

def test_lt_invalid(this_mod, invalid_op_mod):
    with pytest.raises(TypeError):
        assert this_mod < invalid_op_mod

# Test Less or Equal

def test_le_true(this_mod, other_mod):
    assert this_mod <= copy(this_mod)
    assert this_mod <= 2
    assert other_mod <= this_mod
    assert this_mod <= 5

def test_le_false(this_mod, other_mod):
    assert not (this_mod <= other_mod)
    assert not (this_mod <= -1)

def test_le_invalid(this_mod, invalid_op_mod):
    with pytest.raises(TypeError):
        assert this_mod <= invalid_op_mod

# Test Greater Than
        
def test_gt_true(this_mod, other_mod):
    assert this_mod > other_mod
    assert this_mod > 0

def test_gt_false(this_mod, other_mod):
    assert not (other_mod > this_mod)
    assert not (this_mod > 5)

def test_gt_invalid(this_mod, invalid_op_mod):
    with pytest.raises(TypeError):
        assert this_mod > invalid_op_mod
        
# Test Greater or Equal
        
def test_ge_true(this_mod, other_mod):
    assert this_mod >= copy(this_mod)
    assert this_mod >= 2
    assert this_mod >= other_mod
    assert this_mod >= 0

def test_ge_false(this_mod, other_mod):
    assert not (other_mod >= this_mod)
    assert not (this_mod >= 5)

def test_ge_invalid(this_mod, invalid_op_mod):
    with pytest.raises(TypeError):
        assert this_mod >= invalid_op_mod
        
# Test Sorting

def test_sorting_unsorted(this_mod, other_mod):
    assert sorted([this_mod, other_mod]) == [other_mod, this_mod]

def test_sorting_sorted(this_mod, other_mod):
    assert sorted([other_mod, this_mod]) == [other_mod, this_mod]

# Test Hash
        
def test_hash(this_mod):
    assert hash(this_mod) == hash(('mod', this_mod.value, this_mod.modulus))
    assert hash(this_mod) == hash(copy(this_mod))

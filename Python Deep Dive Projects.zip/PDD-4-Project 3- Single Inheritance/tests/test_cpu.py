import pytest
import os
import sys
sys.path.append(os.getcwd())
from src.resources import CPU

def test_init_success():
    cpu1 = CPU('asd','aaa', 3, cores=4, socket='asdf', power_watts=234)
    assert cpu1._allocated == 0
    assert cpu1._power_watts == 234
    assert cpu1._socket == 'asdf'
    assert cpu1._cores  == 4
    assert cpu1._manufacturer == 'aaa'
    assert cpu1._name == 'asd'
    assert cpu1._total == 3

parameter_list_type_error = [
    (123, 'amd', 3, 3, '234', 2344),
    ('i3-234', 123, 4, 4, '222', 222),
    ('ryzen 2344', 'amd', '123', 5, '222', 345),
    ('snapdragon-554', 'qualcomm', 3, '33', 'ss2', 345),
    ('i5-56', 'intel', 6, 8, 775, 456),
    ('Threadripper 38', 'amd', 4, 88, '33l', '34d')
]

@pytest.mark.parametrize('name, manufacturer, total, cores, socket, power_watts', parameter_list_type_error)
def test_init_type_error(name, manufacturer, total, cores, socket, power_watts):
    with pytest.raises(TypeError):
        CPU(name, manufacturer, total, cores=cores, socket=socket, power_watts=power_watts)

parameter_list_value_error = [
    ('123', 'amd', -1, 3, '234', 2344),
    ('i3-234', '123', 4, 0, '222', 222),
    ('ryzen 2344', 'amd', 0, 5, '222', 0),
]

@pytest.mark.parametrize('name, manufacturer, total, cores, socket, power_watts', parameter_list_value_error)
def test_init_value_error(name, manufacturer, total, cores, socket, power_watts):
    with pytest.raises(ValueError):
        CPU(name, manufacturer, total, cores=cores, socket=socket, power_watts=power_watts)

def test_getters(cpu1: pytest.FixtureDef[CPU]):
    assert cpu1.name == 'i3-380M'
    assert cpu1.manufacturer == 'intel'
    assert cpu1.total == 5
    assert cpu1.allocated == 0
    assert cpu1.cores == 4
    assert cpu1.power_watts == 119
    assert cpu1.socket == 'L775'

def test_repr(cpu1: pytest.FixtureDef[CPU]):
    assert repr(cpu1) == 'CPU(i3-380M, intel, total=5, allocated=0, cores=4, socket=L775, power_watts=119)'

if __name__ == "__main__":
    pytest.main(['./tests/test_cpu.py'])
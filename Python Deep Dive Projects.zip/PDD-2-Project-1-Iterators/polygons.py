from polygon import Polygon


class Polygons:

    def __init__(self, max_nr_edges, c_radius):
        if max_nr_edges < 3:
            raise ValueError('A polygon must have a minimum of 3 edges')
        self.list = []
        for i in range(3, max_nr_edges + 1):
            self.list.append(Polygon(i, c_radius))

    @property
    def max_eff_poly(self):
        return sorted(self.list, key=lambda x: x.area / x.perimeter)[-1]

    def __getitem__(self, index):
        if index >= len(self.list):
            raise IndexError('index out of bounds')
        else:
            return self.list[index]

    def __len__(self):
        return len(self.list)

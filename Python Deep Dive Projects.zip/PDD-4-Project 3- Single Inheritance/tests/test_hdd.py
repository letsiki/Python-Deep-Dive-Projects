import pytest
import os
import sys
sys.path.append(os.getcwd())
from src.resources import HDD

def test_init_success():
    hdd1 = HDD('asd','aaa', 3, capacity_GB=128, size='sss', rpm=3222)
    assert hdd1._allocated == 0
    assert hdd1.capacity_GB == 128
    assert hdd1._manufacturer == 'aaa'
    assert hdd1._name == 'asd'
    assert hdd1._total == 3
    assert hdd1._size == 'sss'
    assert hdd1._rpm == 3222

parameter_list_type_error = [
    (123, 'amd', 3, 3, 'sss', 1234),
    ('i3-234', 123, 4, 4, 'sss', 1234),
    ('ryzen 2344', 'amd', '123', 5, 'sss', 1234),
    ('snapdragon-554', 'qualcomm', 3, '33', 'sss', 1234),
    ('123', 'amd', 3, 3, 123, 1234),
    ('123', 'amd', 3, 3, 'sss', '1234'),
]

@pytest.mark.parametrize('name, manufacturer, total, capacity_GB, size, rpm', parameter_list_type_error)
def test_init_type_error(name, manufacturer, total, capacity_GB, size, rpm):
    with pytest.raises(TypeError):
        HDD(name, manufacturer, total, capacity_GB=capacity_GB, size=size, rpm=rpm)

parameter_list_value_error = [
    ('123', 'amd', -1, 3, 'sss', 1234),
    ('123', 'amd', 3, 0, 'sss', 1234),
    ('123', 'amd', 3, 3, 'sss', 0)
]

@pytest.mark.parametrize('name, manufacturer, total, capacity_GB, size, rpm', parameter_list_value_error)
def test_init_value_error(name, manufacturer, total, capacity_GB, size, rpm):
    with pytest.raises(ValueError):
        HDD(name, manufacturer, total, capacity_GB=capacity_GB, size=size, rpm=rpm)

def test_getters(hdd1: pytest.FixtureDef[HDD]):
    assert hdd1.name == 'generic hard disk'
    assert hdd1.manufacturer == 'oem'
    assert hdd1.total == 5
    assert hdd1.allocated == 0
    assert hdd1.capacity_GB == 128
    assert hdd1.size == '2.5\"'
    assert hdd1.rpm == 7200


def test_repr(hdd1: pytest.FixtureDef[HDD]):
    assert repr(hdd1) == 'HDD(generic hard disk, oem, total=5, allocated=0, capacity_GB=128, size=2.5\", rpm=7200)'

if __name__ == "__main__":
    pytest.main(['./tests/test_hdd.py'])
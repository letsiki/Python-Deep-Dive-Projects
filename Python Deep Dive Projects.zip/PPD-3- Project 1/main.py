# TODO: As Fred, hinted, I should probably figure out a recursive solution to this.
# so the function goes through a dictionary's keys (template) and as it goes checks if those keys exist
# in the other. If not we raise a KeyError. If they match, it then checks for the values. if the value 
# in the template (second one) is equal to int or string then tyoe of the first one must be int or string if not we raise a ValueError.
# Else we call the function again (if no string or int it must be a dict) passing the data[currentkey] and template[currentkey]
# The function will eventually return True. All the recursice call will return True as well but we will not be storing them anywhere.
# The functions will be ran naked, therefore only the first one will return something.
# This is unreal! Got it right in the first take. Not even a typo. He talked about helper functions but seems quitte clean like that

# TODO 2: Go for a second version that return the exact location of the error no matter how deep it is
# Took a lot more time than the other but finished

# A few things I could potentially improve to make it more unniversal... First use isinstance instead of type to also support custom subclasses. In the 
# same fashion also check the dictionary's type. Another thing to do is to create custom Exceptions like Fred does.

from data import *

def validate(data, template):
    location = 'root'

    def recurse(data, template):
        nonlocal location
        for key, type_ in template.items():
            if key not in data:
                raise KeyError(f'"{key}" was expected, but not found in dict {location}')
            elif type_ == int or type_ == str:
                if type_ != type(data[key]):
                    raise TypeError(f'{type_} was expected, but {type(data[key])} was found in key "{key}" of dict {location}')
            else:
                location += '.' + str(key)  # convert just in case
                recurse(data[key], template[key])
        location = location.split('.')[:-1]
        location = '.'.join(location)
    recurse(data, template)
    return True



try:
    print(validate(john, template))
except (KeyError,TypeError) as e:
    print(e)

try:
    print(validate(eric, template))
except (KeyError, TypeError) as e:
    print(e)

try:
    print(validate(michael, template))
except (KeyError, TypeError) as e:
    print(e)

try:
    print(validate(alex, template))
except (KeyError, TypeError) as e:
    print(e)

try:
    print(validate(bob, template))
except (KeyError, TypeError) as e:
    print(e)


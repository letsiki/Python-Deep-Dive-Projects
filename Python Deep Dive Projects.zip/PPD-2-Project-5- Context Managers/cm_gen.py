import csv
from collections import namedtuple
from contextlib import contextmanager

@contextmanager
def CSV_Open(fname):
    f = open(fname, 'r')
    try:
        yield cvs_iter(f)
    finally:
        f.close()

class cvs_iter:
    def __init__(self, f):
        sample = f.readline()
        dialect = csv.Sniffer().sniff(sample)
        self.reader = csv.reader(f, dialect=dialect)
        f.seek(0)
        # next(self.reader)
        self.Entry = namedtuple('Entry', next(self.reader))

    def __iter__(self):
        return self
    
    def __next__(self):
        return self.Entry(*next(self.reader))
    
    # I could have done it by including the sample work before the yield and then yielding tuples by using a generator
    # expression instead of creating a new class iterator!
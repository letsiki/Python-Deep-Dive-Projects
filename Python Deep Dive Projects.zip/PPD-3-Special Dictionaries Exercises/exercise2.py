eye_colors = ("amber", "blue", "brown", "gray", "green", "hazel", "red", "violet")

class Person:
    def __init__(self, eye_color):
        self.eye_color = eye_color

from random import seed, choices
seed(0)
persons = [Person(color) for color in choices(eye_colors[2:], k = 50)]

from collections import Counter

my_dict = Counter(dict.fromkeys(eye_colors, 0))

my_dict.update([person.eye_color for person in persons])


print(my_dict)


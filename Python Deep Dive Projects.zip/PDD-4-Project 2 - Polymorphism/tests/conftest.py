import pytest
import os
import sys
sys.path.append(os.getcwd())
from src.mod import Mod

@pytest.fixture
def this_mod():
    return Mod(2, 3)

@pytest.fixture
def other_mod():
    return Mod(1, 3)

@pytest.fixture
def invalid_op_mod():
    return Mod(3, 4)
from solutionpt1 import *
from collections import defaultdict


def violation_counts_by_make():
    makes_counts = defaultdict(int)
    for data in parsed_data():
        makes_counts[data.vehicle_make] += 1

    return {make: cnt
            for make, cnt in sorted(makes_counts.items(),
                                    key=lambda t: t[1],
                                    reverse=True)
            }


if __name__ == '__main__':
    print(violation_counts_by_make())

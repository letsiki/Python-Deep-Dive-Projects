import enum
from requests.exceptions import HTTPError

@enum.unique
class AppException(enum.Enum):

    BadRequest = (400, HTTPError, 'Bad Request')
    Unauthorized = (401, HTTPError, 'Unauthorized')
    PaymentRequired = (402, HTTPError, 'Payment Required')
    Forbidden = (403, HTTPError, 'Forbidden')
    NotFound = (404, HTTPError, 'Not Found')
    MethodNotAllowed = (405, HTTPError, 'Method Not Allowed')
    NotAcceptable = (406, HTTPError, 'Not Acceptable')
    ProxyAuthenticationRequired = (407, HTTPError, 'Proxy Authentication Required')
    RequestTimeout = (408, HTTPError, 'Request Timeout')
    Conflict = (409, HTTPError, 'Conflict')
    Gone = (410, HTTPError, 'Gone')
    LengthRequired = (411, HTTPError, 'Length Required')
    PreconditionFailed = (412, HTTPError, 'Precondition Failed')
    PayloadTooLarge = (413, HTTPError, 'Payload Too Large')
    UriTooLong = (414, HTTPError, 'URI Too Long')
    UnsupportedMediaType = (415, HTTPError, 'Unsupported Media Type')
    RangeNotSatisfiable = (416, HTTPError, 'Range Not Satisfiable')
    ExpectationFailed = (417, HTTPError, 'Expectation Failed')
    MisdirectedRequest = (421, HTTPError, 'Misdirected Request')
    UnprocessableEntity = (422, HTTPError, 'Unprocessable Entity')
    Locked = (423, HTTPError, 'Locked')
    FailedDependency = (424, HTTPError, 'Failed Dependency')
    UpgradeRequired = (426, HTTPError, 'Upgrade Required')
    PreconditionRequired = (428, HTTPError, 'Precondition Required')
    TooManyRequests = (429, HTTPError, 'Too Many Requests')
    RequestHeaderFieldsTooLarge = (431, HTTPError, 'Request Header Fields Too Large')
    UnavailableForLegalReasons = (451, HTTPError, 'Unavailable For Legal Reasons')
    InternalServerError = (500, HTTPError, 'Internal Server Error')

    def __new__(cls, code, exception, message):
        member = object.__new__(cls)

        if isinstance(code, int):
            member._value_ = code
        else:
            raise ValueError(f'value for code must be an int,. {code} of type {type(code)} was provided')
        
        if issubclass(exception, Exception):
            member._exception = exception
        else:
            raise ValueError(f'exception must be a valid Exception. {exception} of type {type(exception)} was provided')

        if isinstance(message, str):
            member._message = message
        else:
            raise ValueError(f'message must be a valid string. {message} of type {type(message)} was provided')              
        
        return member

    @property
    def message(self):
        return self._message
    
    def throw(self, message=None):
        if message == None:
            raise self._exception(self._message)
        else:
            raise self._exception(message)
        
# if __name__ == '__main__':
    
#     for app_ex in AppException.__members__.values():
#         print(app_ex.name, app_ex.value, app_ex._exception, app_ex.message, sep='\t')

#     try:
#         AppException(408).throw()
#     except HTTPError as ex:
#         print(ex)

#     try:
#         AppException(400).throw("Pretty Bad Request")
#     except HTTPError as ex:
#         print(ex)

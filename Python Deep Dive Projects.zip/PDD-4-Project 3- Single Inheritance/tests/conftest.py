import pytest
import os
import sys
sys.path.append(os.getcwd())
from src.resources import Resource, CPU, Storage, HDD, SSD

@pytest.fixture
def resource1() -> Resource:
    return Resource('Radeon 6700 XT', 'AMD', 3)

@pytest.fixture
def cpu1() -> CPU:
    return CPU('i3-380M', 'intel', 5, cores=4, socket='L775', power_watts=119 )

@pytest.fixture
def storage1() -> Storage:
    return Storage('generic hard disk', 'oem', 5, capacity_GB=128)

@pytest.fixture
def ssd1() -> Storage:
    return SSD('generic hard disk', 'oem', 5, capacity_GB=128, interface='nvMe 1.32')

@pytest.fixture
def hdd1() -> Storage:
    return HDD('generic hard disk', 'oem', 5, capacity_GB=128, size='2.5\"', rpm=7200)
# import csv

# reader = csv.reader(open('cars.csv'), delimiter=';')
# print('__next__' in dir(reader))

from cm_gen import CSV_Open

with CSV_Open('personal_info.csv') as f:
    for _ in range(5):
        print(next(f))
    # print(f.closed)

# print(f.closed)

# f = open('cars.csv', 'r')
# sample = f.readline()
# print(sample)
# f.close()
# f = open('cars.csv', 'r')
# sample = f.readline()
# print(sample)

# print(sample)
# dialect = csv.Sniffer().sniff(sample)
# reader = csv.reader(f, dialect=dialect)
# print(next(reader))
# f.close()

import cm_gen
import pytest
import os
import sys
sys.path.append(os.getcwd())
from src.mod import Mod

# Usualy parametrize is used for Input/ExpectedValue pairs. 
# It made sense for me to use it to provide parameters for my 
# init method.

@pytest.mark.parametrize('value, modulus', [(13, 3), (35, 47), (-23, 25), (0, 1)])  
def test_mod_init_success(value, modulus):
    mod = Mod(value, modulus)
    assert mod._modulus == modulus
    assert mod._value == value % modulus

@pytest.mark.parametrize('value, modulus', [(13, -3), (35, 0), (-23.5, 25), ('0', 1)])  
def test_mod_init_invalid(value, modulus):
    with pytest.raises(ValueError):
        mod = Mod(value, modulus)


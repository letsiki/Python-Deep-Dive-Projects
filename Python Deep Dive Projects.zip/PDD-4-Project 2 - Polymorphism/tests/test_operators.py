import pytest
import os
import sys
from copy import copy
sys.path.append(os.getcwd())
from src.mod import Mod

def test_add(this_mod, other_mod):
    assert this_mod + other_mod == Mod(0, 3)
    assert this_mod + this_mod == Mod(1, 3)
    assert other_mod + other_mod == Mod(2, 3)
    assert other_mod + 6 == Mod(1, 3)
    assert this_mod + 1 == Mod(0, 3)

def test_radd(this_mod):
    assert 1 + this_mod == Mod(0, 3)
    assert 2 + this_mod == Mod(1, 3)
    assert 3 + this_mod == this_mod

def test_iadd(this_mod, other_mod):
    # used to check id after operations
    test_mod = this_mod
    # checking operations
    test_mod += other_mod
    assert test_mod == Mod(0, 3)
    test_mod += 2
    assert test_mod == Mod(2, 3)
    # checking id
    assert test_mod is this_mod

def test_sub(this_mod, other_mod):
    assert this_mod - other_mod == Mod(1, 3)
    assert other_mod - this_mod == Mod(-1, 3)
    assert other_mod - other_mod == Mod(0, 3)
    assert other_mod - 6 == Mod(-2, 3)
    assert this_mod - 1 == Mod(1, 3)

def test_rsub(this_mod):
    assert 1 - this_mod == Mod(-1, 3)
    assert 2 - this_mod == Mod(0, 3)
    assert 3 - this_mod == Mod(1, 3)

def test_isub(this_mod, other_mod):
    # used to check id after operations
    test_mod = this_mod
    # checking operations
    test_mod -= other_mod
    assert test_mod == Mod(1, 3)
    test_mod -= 2
    assert test_mod == Mod(-1, 3)
    # checking id
    assert test_mod is this_mod

def test_mul(this_mod, other_mod):
    assert this_mod * other_mod == Mod(2, 3)
    assert this_mod * this_mod == Mod(4, 3)
    assert other_mod * other_mod == Mod(1, 3)
    assert other_mod * 2 == Mod(2, 3)
    assert this_mod * 3 == Mod(0, 3)

def test_rmul(this_mod):
    assert 1 * this_mod == Mod(2, 3)
    assert 2 * this_mod == Mod(1, 3)
    assert 4 * this_mod == this_mod

def test_imul(this_mod, other_mod):
    # used to check id after operations
    test_mod = this_mod
    # checking operations
    test_mod *= other_mod
    assert test_mod == Mod(2, 3)
    test_mod *= 2
    assert test_mod == Mod(1, 3)
    # checking id
    assert test_mod is this_mod

def test_pow(this_mod, other_mod):
    assert this_mod ** other_mod == Mod(2, 3)
    assert this_mod ** this_mod == Mod(1, 3)
    assert other_mod ** other_mod == Mod(1, 3)
    assert other_mod ** 2 == Mod(1, 3)
    assert this_mod ** 3 == Mod(2, 3)

def test_rpow(this_mod):
    assert 1 ** this_mod == Mod(1, 3)
    assert 2 ** this_mod == Mod(1, 3)
    assert 3 ** this_mod == Mod(0, 3)

def test_ipow(this_mod, other_mod):
    # used to check id after operations
    test_mod = this_mod
    # checking operations
    test_mod **= other_mod
    assert test_mod == Mod(2, 3)
    test_mod **= 4
    assert test_mod == Mod(1, 3)
    # checking id
    assert test_mod is this_mod


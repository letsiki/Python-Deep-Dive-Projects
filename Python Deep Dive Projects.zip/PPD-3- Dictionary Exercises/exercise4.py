n1 = {'employees': 100, 'employee': 5000, 'users': 10, 'user': 100}
n2 = {'employees': 250, 'users': 23, 'user': 230}
n3 = {'employees': 150, 'users': 4, 'login': 1000}

def func(n1, n2, n3):
    incomplete_keys = (n1.keys() | n2.keys() | n3.keys()) - (n1.keys() & n2.keys() & n3.keys())
    dicts_list = [n1, n2, n3]
    final_dict = dict()
    for key in incomplete_keys:
        final_dict[key] = []
        for d in dicts_list:
            final_dict[key].append(d.get(key, 0))
        final_dict[key] = tuple(final_dict[key]) 
    return final_dict

# it works but I dont know why my verison is so complicated... Maybe becaue mine is clloser to being dynamic and accepting multiple dicts
# Let's see Fred's

def func(n1, n2, n3):
    incomplete_keys = (n1.keys() | n2.keys() | n3.keys()) - (n1.keys() & n2.keys() & n3.keys())
    return {
        key: (n1.get(key, 0), n2.get(key, 0), n3.get(key, 0))
        for key in incomplete_keys
    }

print(func(n1, n2, n3))




# result = {'employee': (5000, 0, 0),
#           'user': (100, 230, 0),
#           'login': (0, 0, 1000)}
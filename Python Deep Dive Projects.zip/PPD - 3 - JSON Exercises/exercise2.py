from exercise1 import json_string, json, Stock, Trade, Decimal, datetime
import re

class CustomDecoder(json.JSONDecoder):
    def decode(self, arg): # This will receive the entire string
        pattern_stock = r'"type"\s*:\s*Stock'
        pattern_trade = r'"type"\s*:\s*Trade'
        pattern_datetime = r'"type"\s*:\s*datetime'
        pattern_decimal = r'"type"\s*:\s*decimal'
        print('i got called')


# a = json.loads(json_string, object_hook=lambda x:print(type(x)))  # simple test to verify that object hook only receives dicts
# from pprint import pprint
# pprint(a)
        

"""
we do not need to look for dates or decimals they only exist as part of stocks or trades
so we basically call loads and convert it all to dictionaries
we identify stocks and trades by their object type item
and then we create them using their date and decimal items
"""
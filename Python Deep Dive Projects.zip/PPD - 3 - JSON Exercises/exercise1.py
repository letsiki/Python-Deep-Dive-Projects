from main import Stock, Trade, activity, Decimal, datetime

import json
from functools import singledispatch

class CustomEncoder(json.JSONEncoder):
   
    @singledispatch
    def encode_(arg):
        return super().default(arg)
    
    @encode_.register(Stock)
    def _(arg: Stock):
        return arg.to_dict()
    
    @encode_.register(Trade)
    def _(arg: Trade):
        return arg.to_dict()

    @encode_.register(Decimal)
    def _(arg: Decimal):
         decimaldict = dict(
            type = "decimal",
            value = str(arg)
        )
         return decimaldict

    @encode_.register(datetime)
    def _(arg: datetime):
        return dict(
            type = "datetime",
            value = arg.isoformat()
        )

    def default(self, arg):
        return CustomEncoder.encode_(arg)
    
# default doesn't return the JSON representation; it returns a JSON-serializable value. encode returns a JSON representation, in part by using default.

json_string = json.dumps(activity, cls=CustomEncoder, indent=2)

if __name__ == '__main__':
    print(json_string)
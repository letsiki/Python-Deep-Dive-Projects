import pytest
import os
import sys
sys.path.append(os.getcwd())
from src.resources import Resource

def test_init_success():
    r1 = Resource('i7', 'intel', 22)
    r2 = Resource('Ryzen 2600', 'AMD')
    assert r1._name == 'i7'
    assert r1._manufacturer == 'intel'
    assert r1._total == 22
    assert r1._allocated == 0
    assert r2._total == 0

def test_init_invalid():
    with pytest.raises(ValueError):
        Resource('i9', 'intel', -15)
    with pytest.raises(TypeError):
        Resource(123, 'intel', 8)
    with pytest.raises(TypeError):
        Resource('i9', 456)

def test_getters(resource1: pytest.FixtureDef[Resource]):
    assert resource1.name == 'Radeon 6700 XT'
    assert resource1.manufacturer == 'AMD'
    assert resource1.total == 3
    assert resource1.allocated == 0

def test_repr_str(resource1: pytest.FixtureDef[Resource]):
    assert str(resource1) == 'Radeon 6700 XT'
    assert repr(resource1) == 'Resource(Radeon 6700 XT, AMD, total=3, allocated=0)'

def test_category(resource1):
    assert resource1.category == 'resource'

def test_available(resource1):
    resource1._allocated = 1
    assert resource1.available == 2

def test_valid_input():
    assert Resource.check_valid_quantity_input(3) == True
    assert Resource.check_valid_quantity_input(3, value_desc='asd') == True
    assert Resource.check_valid_quantity_input(0, allow_zero=True) == True
    assert Resource.check_valid_quantity_input(0, allow_zero=True, value_desc='asd asd') == True

def test_invalid_input():
    with pytest.raises(TypeError) as e:
        Resource.check_valid_quantity_input('asd', value_desc='qwe')
    assert str(e.value) == 'Please enter a integer value for qwe'

    with pytest.raises(ValueError) as e:
        Resource.check_valid_quantity_input(-5)
    assert str(e.value) == 'Please enter a positive value for quantity'

    with pytest.raises(ValueError)as e:
        Resource.check_valid_quantity_input(0)
    assert str(e.value) == 'Please enter a positive value for quantity'

def test_claim_valid(resource1):
    resource1.claim(2)
    assert resource1._allocated == 2
    resource1.claim(1)
    assert resource1._allocated == 3

def test_claim_valid_invalid(resource1):
    with pytest.raises(ValueError) as e:
        resource1.claim(4)
    assert str(e.value) == 'Insufficient Quantity to claim'
    # test that valid quantity method gets activated
    with pytest.raises(ValueError) as e:
        resource1.claim(0)
    assert str(e.value) == 'Please enter a positive value for quantity claimed'

def test_freeup_valid(resource1):
    resource1.claim(2)
    resource1.freeup(2)
    assert resource1._allocated == 0

def test_free_up_invalid(resource1):
    with pytest.raises(ValueError) as e:
        resource1.freeup(1)
    assert str(e.value) == 'Insufficient Quantity to free up'
    # test that valid quantity method gets activated
    with pytest.raises(ValueError) as e:
        resource1.freeup(0)
    assert str(e.value) == 'Please enter a positive value for quantity to free up'

def test_died_valid(resource1):
    resource1._allocated = 2
    resource1.died(1)
    assert resource1._allocated == 1
    assert resource1._total == 2

def test_died_invalid(resource1):
    with pytest.raises(ValueError) as e:
        resource1.died(1)
    assert str(e.value) == 'Insufficient Quantity to retire'
    # test that valid quantity method gets activated
    with pytest.raises(ValueError) as e:
        resource1.died(0)
    assert str(e.value) == 'Please enter a positive value for quantity to retire'

def test_purchased_valid(resource1):
    resource1.purchased(15)
    assert resource1._total == 18
    assert resource1._allocated == 0

def test_purchased_invalid(resource1):
    # test that valid quantity method gets activated
    with pytest.raises(ValueError) as e:
        resource1.purchased(0)
    assert str(e.value) == 'Please enter a positive value for quantity to purchase'

if __name__ == "__main__":
    pytest.main(['./tests/test_resource.py'])





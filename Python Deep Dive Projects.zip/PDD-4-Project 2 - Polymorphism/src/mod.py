from functools import total_ordering

@total_ordering
class Mod:

    # Init (Tested)

    def __init__(self, value, modulus):
        if all((isinstance(value, int), isinstance(modulus, int), modulus > 0)):
            self._modulus = modulus
            self._value = value % modulus
        else:
            raise ValueError('Modulus must be a positive integer and Value must be an integer')
        
    # Getters (Tested)
    
    @property
    def modulus(self):
        return self._modulus
    
    @property
    def value(self):
        return self._value
        
    # Ordering and hash
    
    def __eq__(self, other):
        if isinstance(other, Mod) and other._modulus == self._modulus:
            return self._value == other._value
        elif isinstance(other, int):
            # The code below seems to mess up the le but not the lt
            # should probably be avoiding recursion when using total_ordering
            # return self == Mod(other, self._modulus)
            return self._value == other
        else:
            raise TypeError('Mod can only be compared to integers or same modulus mods')
        
    def __gt__(self, other):
        if isinstance(other, int):
            # The code below seems to mess up the le but not the lt
            # should probably be avoiding recursion when using total_ordering
            # return self > Mod(other, self._modulus)
            return self._value > other
        elif isinstance(other, Mod) and other._modulus == self._modulus:
            return self._value > other._value
        else:
            raise TypeError('Mod can only be compared to integers or same modulus mods')
        
    def __hash__(self) -> int:
        return hash(('mod', self._value, self._modulus))
    
    # Representation and Conversion

    def __repr__(self):
        return f'Mod({self._value}, {self._modulus})'
    
    def __int__(self):
        return self._value
    
    # Operations

    def __add__(self, other):
        if isinstance(other, Mod) and other._modulus == self._modulus:
            return Mod(self._value + other._value, self._modulus)
        elif isinstance(other, int):
            return Mod(self._value + other, self._modulus)
        else:
            return NotImplemented

    def __radd__(self, other):
        if isinstance(other, int):
            return Mod(self._value + other, self._modulus)
        else:
            return NotImplemented
        
    def __iadd__(self, other):
        if isinstance(other, Mod) and other._modulus == self._modulus:
            self.__init__(self._value + other._value, self._modulus)
            return self
        elif isinstance(other, int):
            self.__init__(self._value + other, self._modulus)
            return self
        else:
            return NotImplemented

    def __sub__(self, other):
        if isinstance(other, Mod) and other._modulus == self._modulus:
            return Mod(self._value - other._value, self._modulus)
        elif isinstance(other, int):
            return Mod(self._value - other, self._modulus)
        else:
            return NotImplemented

    def __rsub__(self, other):
        if isinstance(other, int):
            return Mod(other - self._value, self._modulus)
        else:
            return NotImplemented

    def __isub__(self, other):
        if isinstance(other, Mod) and other._modulus == self._modulus:
            self.__init__(self._value - other._value, self._modulus)
            return self
        elif isinstance(other, int):
            self.__init__(self._value - other, self._modulus)
            return self
        else:
            return NotImplemented

    def __mul__(self, other):
        if isinstance(other, Mod) and other._modulus == self._modulus:
            return Mod(self._value * other._value, self._modulus)
        elif isinstance(other, int):
            return Mod(self._value * other, self._modulus)
        else:
            return NotImplemented

    def __rmul__(self, other):
        if isinstance(other, int):
            return Mod(self._value * other, self._modulus)
        else:
            return NotImplemented

    def __imul__(self, other):
        if isinstance(other, Mod) and other._modulus == self._modulus:
            self.__init__(self._value * other._value, self._modulus)
            return self
        elif isinstance(other, int):
            self.__init__(self._value * other, self._modulus)
            return self
        else:
            return NotImplemented

    def __pow__(self, other):
        if isinstance(other, Mod) and other._modulus == self._modulus:
            return Mod(self._value ** other._value, self._modulus)
        elif isinstance(other, int):
            return Mod(self._value ** other, self._modulus)
        else:
            return NotImplemented

    def __rpow__(self, other):
        if isinstance(other, int):
            return Mod(other ** self._value, self._modulus)
        else:
            return NotImplemented

    def __ipow__(self, other):
        if isinstance(other, Mod) and other._modulus == self._modulus:
            self.__init__(self._value ** other._value, self._modulus)
            return self
        elif isinstance(other, int):
            self.__init__(self._value ** other, self._modulus)
            return self
        else:
            return NotImplemented

        
if __name__ == '__main__':
    print('Completed 410 lines of code!')

from collections import namedtuple
import csv

class CSV_Open:

    def __init__(self, csv_file):
        self._csv_file = csv_file

    def __enter__(self):
        self._f = open(self._csv_file, 'r')
        sample = self._f.readline()
        dialect = csv.Sniffer().sniff(sample)
        self._reader = csv.reader(self._f, dialect=dialect)
        self._f.seek(0)
        self._Entry = namedtuple('Entry', next(self._reader))
        return self
        
    def __exit__(self, exc_type, exc_value, exc_tb):
        self._f.close()
        return False
    
    def __iter__(self):
        return self
    
    def __next__(self):
        return self._Entry(*next(self._reader))
    
    @property
    def closed(self):
        return self._f.closed


        


from account import Account
import unittest

"""
unit testing expects a class to work with. Within that class we define methods that need the prefix 'test_' in their name.
This way unit test handlers know that the function is a test. We can also define helper functions that do not utilize the 
prefix. Furthermore, we can define a 'setUp' and 'tearDown' function (those ecxact names) that will run before and after
every tst function respectivily. There is also different types of assertions we can do, for which I will be commenting
inline.
"""

def run_tests(test_class):
    suite = unittest.TestLoader().loadTestsFromTestCase(test_class)
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(suite)
    
class TestAccount(unittest.TestCase):
    account_number = 100000  
    # When we run the tests Python essentially runs multiple instances of TestAccount
    # In order to avoid errors we had to provide a class level numbering system to 
    # avoid duplicates

    def setUp(self) -> None:
        # self.account_number = 100000
        self.fname = 'Alex'
        self.lname = 'Jones'
        self.ptz_offset = 3

    def create_account(self, *args, **kwargs):
        TestAccount.account_number += 1  # because this is an assignment self would actually create a new attribute
        # print(self.account_number)
        return Account(self.account_number if not args else args[0],  # Here we can use self.account_number because it is access only and will be looked up at class level
                       fname=self.fname if "fname" not in kwargs else kwargs["fname"], 
                       lname=self.lname if "lname" not in kwargs else kwargs["lname"], 
                       ptz_offset=self.ptz_offset if "ptz_offset" not in kwargs else kwargs["ptz_offset"])
    
    def test_create_account_base_case(self):
        # optionally change arguments here
        account = self.create_account()
        self.assertEqual(self.account_number, account._account_number)
        self.assertEqual(self.fname, account._fname)
        self.assertEqual(self.lname, account._lname)
        self.assertEqual(self.ptz_offset, account._ptz_offset)
        self.assertEqual(0, account._balance)

    def test_wrong_timezone_int(self):
        with self.assertRaises(ValueError):
            self.create_account(ptz_offset=-13)
            
    def test_wrong_timezone_string(self):
        with self.assertRaises(TypeError):
            self.create_account(ptz_offset='SomeTimeZone')

    def test_positive_deposits(self):
        test_deposits = (10, 200, 3000, 40000)
        for i, deposit in enumerate(test_deposits):
            with self.subTest(test_name=f'test #{i}'):
                account = self.create_account()
                account.deposit(deposit)
                self.assertEqual(deposit, account._balance)

    def test_invalid_deposit_and_report_going_through(self):
        test_deposits = (-10, 0)
        for i, deposit in enumerate(test_deposits):
            with self.subTest(test_name=f'test #{i}'):
                account = self.create_account()
                with self.assertRaises(ValueError):
                    account.deposit(deposit)
                self.assertEqual(1, len(account.reports))

run_tests(TestAccount)


from datetime import datetime, timezone, timedelta

class Result:

    def __init__(self, report: str, ptz_offset):
        report_list = report.split('-')
        self.account_number = report_list[1]
        self.transaction_code = report_list[0]
        self.transaction_id = report_list[3]
        self._datetime_obj_utc = Result.str_to_date(report_list[2])
        self._datetime_obj_ptz = Result.str_to_date(report_list[2]) + timedelta(hours=ptz_offset)
        self.time = datetime.strftime(self._datetime_obj_ptz, '%Y-%m-%d %H:%M:%S') + f' (TZ:{ptz_offset})'
        self.time_utc = datetime.strftime(self._datetime_obj_utc, '%Y-%m-%dT%H:%M:%S')
    
    @staticmethod
    def str_to_date(s: str):
        return datetime.strptime(s, '%Y%m%d%H%M%S')

class Account:
    _account_numbers = set()
    _interest_rate = 0.02
    _transaction_id = 0

    def __init__(self, account_number, *, fname, lname, ptz_offset):
        if self._is_an_in_use(account_number):
            raise ValueError('account id already exists')
        else:
            self._account_number = account_number
            self._add_an(account_number)
        self._fname = fname
        self._lname = lname
        self.ptz_offset = ptz_offset
        self._balance = 0
        self.reports = []

    @classmethod
    def _is_an_in_use(cls, account_number):
        return account_number in cls._account_numbers

    @classmethod
    def _add_an(cls, account_number):
        cls._account_numbers.add(account_number)

    @property
    def account_number(self):
        return self._account_number
    
    @property
    def fname(self):
        return self._fname
    
    @property
    def lname(self):
        return self._lname
    
    @property
    def ptz_offset(self):
        return self._ptz_offset
    
    @ptz_offset.setter
    def ptz_offset(self, value: int):
        if not isinstance(value, int):
            raise TypeError("tz offset can only be a valid int")
        if -12 <= value <= 12:
            self._ptz_offset = value
        else:
            raise ValueError("Invalid Time Zone offset")

    @property
    def balance(self):
        return round(self._balance, 2)
    
    def _deposit_interest(self):
        interest = self._interest_rate * self.balance
        self.deposit(interest, is_interest=True)

    def deposit(self, value, is_interest=False):
        self._transaction_id += 1
        if value > 0:
            transaction_type = 'I' if is_interest else 'D'
            self._balance += value
            self._generate_report(transaction_type)
        else:
            self._generate_report('X')
            raise ValueError('Invalid Deposit Amount')
        
    def withdraw(self, value):
        self._transaction_id += 1
        if 0 < value <= self.balance:
            self._balance -= value
            self._generate_report('W')
        else:
            self._generate_report('X')
            # raise ValueError('Withdrawal Declined')
        
    def _generate_report(self, trans_type):
        utc_time = datetime.now(timezone.utc)
        utc_time_str = datetime.strftime(utc_time, "%Y%m%d%H%M%S")
        report =  f'{trans_type}-{self.account_number}-{utc_time_str}-{self._transaction_id}'
        # print(report)
        self.reports.append(report)

    def generate_result_object(self, report: str) -> Result:
        return Result(report, self.ptz_offset)
    

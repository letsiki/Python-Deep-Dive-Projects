from pprint import pprint
def current_settings(env: str) -> dict:
    import json
    from collections import ChainMap
    with open(f'{env}.json') as f:
        env_dict = json.load(f)
    with open('common.json') as f:
        common_dict = json.load(f)
    return ChainMap(env_dict, common_dict)

pprint(current_settings("dev"))


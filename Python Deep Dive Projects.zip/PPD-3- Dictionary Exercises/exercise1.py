# My solution

composers = {'Johann': 65, 'Ludwig': 56, 'Frederic': 39, 'Wolfgang': 35}

def value_sorting(d: dict) -> dict:
    return {k: v for k, v in sorted(d.items(), key=lambda x: x[1])}



# Fred's

# we can actually use the constructor instead of a comprehension. He pointed out
# that this is often the case when we are not actually performing an operation on the 
# key-values {k: v for ...}

def value_sorting(d: dict) -> dict:
    return dict(sorted(d.items(), key=lambda x: x[1]))

print(value_sorting(composers))
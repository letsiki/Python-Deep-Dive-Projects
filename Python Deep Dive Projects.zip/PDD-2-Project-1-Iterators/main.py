# TODO 1: Create a Polygon class
#  add initializer: number of edges/vertices and circumradius
#  properties: # edges, # vertices, interior angle, edge length, apothem, area, perimeter
#  functionality: __repr__, __eq__ based on # vertices and circumradius, __gt__ based on vertices only
import math

# TODO 2: Create a Polygon Sequence type
#  add initializer: Number of vertices for largest Polygon in a sequence n >= 3, and a circumradius.
#  properties: max efficiency polygon: returns the Polygon with the highest area to paerimeter ratio
#  functionality: __getitem__, __len__

# NOTES : interior angle = (n -2) * 180 / n
#         edge length s = 2 * R * sin(π/n)
#         apothem a = R * cos(π/n)
#         area = 1/2 * n * s * a
#         apothem is the distance from the center to the middle of an edge
#         vertices are the connection points of edges
#         circumradius is the radius of the circle we draw around the polygon

from polygon import Polygon
from polygons import Polygons

# s = Polygon(4, 32)
# for p in s.__dict__.items():
#     print(p[1])

polys = Polygons(13, 10)
print(polys.max_eff_poly)
print(polys[3])
print(polys[4] < polys[5])


def test_polygon():
    n = 4
    R = 1
    p = Polygon(n, R)
    assert p.interior_angle == 90
    # assert p.area == 2.0, (f'actual: {p.area}, '
    #                        f' expected: {2.0}')
    assert math.isclose(p.area, 2.0), (f'actual: {p.area}, '
                                       f' expected: {2.0}')

    try:
        p = Polygon(2, 10)
        assert False, repr(p)
    except ValueError:
        pass


test_polygon()

import os
import sys
sys.path.append(os.getcwd())
import pytest
from requests.exceptions import HTTPError
from appexception import AppException

def test_app_exception_enum():
    # Test if each enum member has the correct type and values
    for member in AppException:
        assert isinstance(member.value, int)  # Check if code is int
        assert issubclass(member._exception, Exception)  # Check if exception is a subclass of Exception
        assert isinstance(member._message, str)  # Check if message is string
        assert member.message == member._message  # Check if message property is correctly assigned

def test_uniqness():
    # Test if enum members are unique (no aliases)
    values = [member.value for member in AppException]
    assert len(values) == len(set(values))  # Check for uniqueness

def test_throw_method():
    # Test the throw method with default message
    with pytest.raises(AppException.BadRequest._exception) as exc_info:
        AppException.BadRequest.throw()
    assert str(exc_info.value) == AppException.BadRequest.message

def test_throw_method_custom_message():
    # Test the throw method with custom message
    custom_message = "Custom Message"
    with pytest.raises(AppException.BadRequest._exception) as exc_info:
        AppException.BadRequest.throw(custom_message)
    assert str(exc_info.value) == custom_message


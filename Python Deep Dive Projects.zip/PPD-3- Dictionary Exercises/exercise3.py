d1 = {'python': 10, 'java': 3, 'c#': 8, 'javascript': 15}
d2 = {'java': 10, 'c++': 10, 'c#': 4, 'go': 9, 'python': 6}
d3 = {'erlang': 5, 'haskell': 2, 'python': 1, 'pascal': 1}

# keys = d1.keys() | d2.keys() | d3.keys()

# d = dict.fromkeys(keys, 0)

# from itertools import chain

# for k, v in chain(d1.items(), d2.items(), d3.items()):
#     d[k] += v

# sortedl = sorted(list(d.items()), key=lambda x:x[1], reverse=True) 

# sortedd = dict(sortedl)

# print(sortedd)

# Let's see if we can make this a function that accepts and arbitrary number of dictionaries

def merge_values(*dicts: dict) -> dict:
    dd = dict()
    for d in dicts:
        for k in d:
            dd[k] = dd.setdefault(k, 0) + d.get(k, 0)
    return  dict(sorted(list(dd.items()), key=lambda x:x[1], reverse=True))

def merge_values_fred(*dicts: dict) -> dict:
    dd = dict()
    for d in dicts:
        for k, v in d.items():
            dd[k] = dd.get(k, 0) + v
    return  dict(sorted(list(dd.items()), key=lambda x:x[1], reverse=True))
    

# print(merge_values_fred(d1, d2, d3))

from timeit import timeit
print(timeit('merge_values(d1, d2, d3)', globals=globals(), number=1_000_000))
print(timeit('merge_values_fred(d1, d2, d3)', globals=globals(), number=1_000_000))

# surprisingly(?) Fred's solution is a tiny bit faster

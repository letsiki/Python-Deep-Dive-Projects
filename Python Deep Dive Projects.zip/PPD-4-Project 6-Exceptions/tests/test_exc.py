import pytest
from http import HTTPStatus
import os
import sys
sys.path.append(os.getcwd())
from widgetexception import (WidgetException, SupplierException, CheckoutException,
                         NotManufacturedException, ProductionDelayedException,
                         ShippingDelayedException, InventoryExceptions,
                         PricingException, OutOfStockException,
                         InvalidCouponException, CouponStackException)


def test_widget_exception():
    with pytest.raises(WidgetException) as exc_info:
        raise WidgetException()
    assert exc_info.value.http_status == HTTPStatus.INTERNAL_SERVER_ERROR
    assert exc_info.value.internal_error_message == 'API Exception Occurred'
    assert exc_info.value.user_error_message == 'An error has Occurred on our end'
    assert exc_info.value.to_json() == '{"status": 500, "message": "An error has Occurred on our end"}'
    assert exc_info.value.log_exception() == {
        "type": "WidgetException",
        "http status": HTTPStatus.INTERNAL_SERVER_ERROR,
        "message": "API Exception Occurred"
    }


def test_supplier_exception():
    with pytest.raises(SupplierException) as exc_info:
        raise SupplierException()
    assert exc_info.value.http_status == HTTPStatus.INTERNAL_SERVER_ERROR
    assert exc_info.value.internal_error_message == 'API Exception Occurred'
    assert exc_info.value.user_error_message == 'An error has Occurred on our end'
    assert exc_info.value.to_json() == '{"status": 500, "message": "An error has Occurred on our end"}'
    assert exc_info.value.log_exception() == {
        "type": "SupplierException",
        "http status": HTTPStatus.INTERNAL_SERVER_ERROR,
        "message": "API Exception Occurred"
    }


def test_checkout_exception():
    with pytest.raises(CheckoutException) as exc_info:
        raise CheckoutException()
    assert exc_info.value.http_status == HTTPStatus.INTERNAL_SERVER_ERROR
    assert exc_info.value.internal_error_message == 'API Exception Occurred'
    assert exc_info.value.user_error_message == 'An error has Occurred on our end'
    assert exc_info.value.to_json() == '{"status": 500, "message": "An error has Occurred on our end"}'
    assert exc_info.value.log_exception() == {
        "type": "CheckoutException",
        "http status": HTTPStatus.INTERNAL_SERVER_ERROR,
        "message": "API Exception Occurred"
    }


def test_not_manufactured_exception():
    with pytest.raises(NotManufacturedException) as exc_info:
        raise NotManufacturedException()
    assert exc_info.value.http_status == HTTPStatus.INTERNAL_SERVER_ERROR
    assert exc_info.value.internal_error_message == 'API Exception Occurred'
    assert exc_info.value.user_error_message == 'An error has Occurred on our end'
    assert exc_info.value.to_json() == '{"status": 500, "message": "An error has Occurred on our end"}'
    assert exc_info.value.log_exception() == {
        "type": "NotManufacturedException",
        "http status": HTTPStatus.INTERNAL_SERVER_ERROR,
        "message": "API Exception Occurred"
    }


def test_production_delayed_exception():
    with pytest.raises(ProductionDelayedException) as exc_info:
        raise ProductionDelayedException()
    assert exc_info.value.http_status == HTTPStatus.INTERNAL_SERVER_ERROR
    assert exc_info.value.internal_error_message == 'API Exception Occurred'
    assert exc_info.value.user_error_message == 'An error has Occurred on our end'
    assert exc_info.value.to_json() == '{"status": 500, "message": "An error has Occurred on our end"}'
    assert exc_info.value.log_exception() == {
        "type": "ProductionDelayedException",
        "http status": HTTPStatus.INTERNAL_SERVER_ERROR,
        "message": "API Exception Occurred"
    }


def test_shipping_delayed_exception():
    with pytest.raises(ShippingDelayedException) as exc_info:
        raise ShippingDelayedException()
    assert exc_info.value.http_status == HTTPStatus.INTERNAL_SERVER_ERROR
    assert exc_info.value.internal_error_message == 'API Exception Occurred'
    assert exc_info.value.user_error_message == 'An error has Occurred on our end'
    assert exc_info.value.to_json() == '{"status": 500, "message": "An error has Occurred on our end"}'
    assert exc_info.value.log_exception() == {
        "type": "ShippingDelayedException",
        "http status": HTTPStatus.INTERNAL_SERVER_ERROR,
        "message": "API Exception Occurred"
    }


def test_inventory_exceptions():
    with pytest.raises(InventoryExceptions) as exc_info:
        raise InventoryExceptions()
    assert exc_info.value.http_status == HTTPStatus.INTERNAL_SERVER_ERROR
    assert exc_info.value.internal_error_message == 'API Exception Occurred'
    assert exc_info.value.user_error_message == 'An error has Occurred on our end'
    assert exc_info.value.to_json() == '{"status": 500, "message": "An error has Occurred on our end"}'
    assert exc_info.value.log_exception() == {
        "type": "InventoryExceptions",
        "http status": HTTPStatus.INTERNAL_SERVER_ERROR,
        "message": "API Exception Occurred"
    }


def test_pricing_exception():
    with pytest.raises(PricingException) as exc_info:
        raise PricingException()
    assert exc_info.value.http_status == HTTPStatus.INTERNAL_SERVER_ERROR
    assert exc_info.value.internal_error_message == 'API Exception Occurred'
    assert exc_info.value.user_error_message == 'An error has Occurred on our end'
    assert exc_info.value.to_json() == '{"status": 500, "message": "An error has Occurred on our end"}'
    assert exc_info.value.log_exception() == {
        "type": "PricingException",
        "http status": HTTPStatus.INTERNAL_SERVER_ERROR,
        "message": "API Exception Occurred"
    }


def test_out_of_stock_exception():
    with pytest.raises(OutOfStockException) as exc_info:
        raise OutOfStockException()
    assert exc_info.value.http_status == HTTPStatus.INTERNAL_SERVER_ERROR
    assert exc_info.value.internal_error_message == 'API Exception Occurred'
    assert exc_info.value.user_error_message == 'An error has Occurred on our end'
    assert exc_info.value.to_json() == '{"status": 500, "message": "An error has Occurred on our end"}'
    assert exc_info.value.log_exception() == {
        "type": "OutOfStockException",
        "http status": HTTPStatus.INTERNAL_SERVER_ERROR,
        "message": "API Exception Occurred"
    }


def test_invalid_coupon_exception():
    with pytest.raises(InvalidCouponException) as exc_info:
        raise InvalidCouponException()
    assert exc_info.value.http_status == HTTPStatus.INTERNAL_SERVER_ERROR
    assert exc_info.value.internal_error_message == 'API Exception Occurred'
    assert exc_info.value.user_error_message == 'An error has Occurred on our end'
    assert exc_info.value.to_json() == '{"status": 500, "message": "An error has Occurred on our end"}'
    assert exc_info.value.log_exception() == {
        "type": "InvalidCouponException",
        "http status": HTTPStatus.INTERNAL_SERVER_ERROR,
        "message": "API Exception Occurred"
    }


def test_coupon_stack_exception():
    with pytest.raises(CouponStackException) as exc_info:
        raise CouponStackException()
    assert exc_info.value.http_status == HTTPStatus.BAD_REQUEST
    assert exc_info.value.internal_error_message == 'API Exception Occurred'
    assert exc_info.value.user_error_message == 'An error has Occurred on our end'
    assert exc_info.value.to_json() == '{"status": 400, "message": "An error has Occurred on our end"}'
    assert exc_info.value.log_exception() == {
        "type": "CouponStackException",
        "http status": HTTPStatus.BAD_REQUEST,
        "message": "API Exception Occurred"
    }

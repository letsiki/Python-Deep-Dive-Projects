import pytest
import os
import sys
sys.path.append(os.getcwd())
from src.mod import Mod

# Usualy parametrize is used for Input/ExpectedValue pairs. 
# It made sense for me to use it to provide parameters for my 
# getter methods.

@pytest.mark.parametrize('value, modulus', [(13, 3), (35, 47), (-23, 25), (0, 1)])  
def test_modulus_getter(value, modulus):
    mod = Mod(value, modulus)
    assert mod.modulus == modulus

@pytest.mark.parametrize('value, modulus', [(13, 3), (35, 47), (-23, 25), (0, 1)])  
def test_value_getter(value, modulus):
    mod = Mod(value, modulus)
    assert mod.value == value % modulus
# TODO: Refactor the classes so that they inherit from the same class and still pass 
#       all the tests as they are BaseValidator

class BaseModel:
    def __init__(self, min_=None, max_=None):
        if min_ is not None and not isinstance(min_, int):
            raise TypeError("min must be an integer value")
        if max_ is not None and not isinstance(max_, int):
            raise TypeError("max must be an integer value")
        self.min_ = min_
        self.max_ = max_
        
    def __set_name__(self, instance, property_name):
        self.property_name = property_name    

    def __get__(self, instance, owner_class):
        if instance is None:
            return self
        return getattr(instance, '_' + self.property_name)
    
class IntegerField(BaseModel):

    def __init__(self, min_=None, max_=None):
        super().__init__(min_, max_)
        if min_ is not None and max_ is not None and min_ > max_:
            raise ValueError("min cannot be greater than the max") 
        self.min_ = min_
        self.max_ = max_

    def __set__(self, instance, value):
        if not isinstance(value, int):
            raise TypeError(f"{self.property_name} can only be an Integer")
        if self.min_ is not None and value < self.min_:
            raise ValueError(f"value for {self.property_name} cannot be less than {self.min_}")
        if self.max_ is not None and value > self.max_:
            raise ValueError(f"value for {self.property_name} cannot be more than {self.max_}")
        setattr(instance, '_' + self.property_name, value)


class CharField(BaseModel):
    def __init__(self, min_=None, max_=None):
        super().__init__(min_, max_)
        if min_ is not None and min_ < 0:
            raise ValueError("min must be a positive integer value")
        if max_ is not None and max_ < 0:
            raise ValueError("max must be a positive integer value")
        if min_ is not None and max_ is not None and min_ > max_:
            raise ValueError("min cannot be greater than the max")
        
    def __set__(self, instance, value):
        if not isinstance(value, str):
            raise TypeError(f"{self.property_name} can only be a String")
        if self.min_ is not None and len(value) < self.min_:
            raise ValueError(f"length for {self.property_name} cannot be less than {self.min_}")
        if self.max_ is not None and len(value) > self.max_:
            raise ValueError(f"length for {self.property_name} cannot be more than {self.max_}")
        setattr(instance, '_' + self.property_name, value)
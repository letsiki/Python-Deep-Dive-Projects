# watch pydantic videos and give it a shot
from exercise1 import json_string, json, Decimal, datetime
from datetime import date
import re
from pydantic import BaseModel, Field, field_serializer, field_validator
from pprint import pprint


class DecimalModel(BaseModel):
    object_type: str = "Decimal"
    value: str


class Stock(BaseModel):

    object_type: str = "Stock"
    symbol: str
    date: date
    open: DecimalModel
    high: DecimalModel
    low: DecimalModel
    close: DecimalModel
    volume: int

    @field_serializer("date", when_used='json-unless-none')
    def date_serializer(self, date):
        return date.strftime("%Y/%m/%d")
    
    @field_validator("date")
    def date_validator(cls, value):
        return
    

class Trade(BaseModel):

    object_type: str = "Stock"
    symbol: str
    timestamp: datetime
    order: str
    price: DecimalModel
    commission: int
    volume: DecimalModel

    @field_serializer("timestamp", when_used='json-unless-none')
    def datetime_serializer(self, datetime):
        return datetime.strftime("%Y/%m/%dT%H:%M:%S")


class StockActivity(BaseModel):

    quotes: list[Stock] = []
    trades: list[Trade] = []

class Model(BaseModel):
    
    data: StockActivity


activity = {
    "quotes": [
        Stock(symbol='TSLA', date=date(2018, 11, 22), 
              open=DecimalModel(value='338.19'), high=DecimalModel(value='338.64'), low=DecimalModel(value='337.60'), close=DecimalModel(value='338.19'), volume=365_607),
        Stock(symbol='AAPL', date=date(2018, 11, 22), 
              open=DecimalModel(value='176.66'), high=DecimalModel(value='177.25'), low=DecimalModel(value='176.64'), close=DecimalModel(value='176.78'), volume=3_699_184),
        Stock(symbol='MSFT', date=date(2018, 11, 22), 
              open=DecimalModel(value='103.25'), high=DecimalModel(value='103.48'), low=DecimalModel(value='103.07'), close=DecimalModel(value='103.11'), volume=4_493_689)
    ],
    
    "trades": [
        Trade(symbol='TSLA', timestamp=datetime(2018, 11, 22, 10, 5, 12), order='buy', price=DecimalModel(value='338.25'), commission=100, volume=DecimalModel(value='9.99')),
        Trade(symbol='AAPL', timestamp=datetime(2018, 11, 22, 10, 30, 5), order='sell', price=DecimalModel(value='177.01'), commission=20, volume=DecimalModel(value='9.99'))
    ]
}   

m1 = Model(data=activity)
j = m1.model_dump_json(indent=2)
print(j)

mv = Model.model_validate_json(j)
dd1 = {'a': 1, 'b': 2, 'c': 3, 'd': 4}
dd2 = {'b': 20, 'c': 30, 'y': 40, 'z': 50}

def common_tuple(d1: dict, d2: dict) -> dict:
    return {k: (d1[k], d2[k]) for k in d1.keys() & d2.keys()}

print(common_tuple(dd1, dd2))
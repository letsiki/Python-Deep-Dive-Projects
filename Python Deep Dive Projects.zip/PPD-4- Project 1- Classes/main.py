from account import Account
from time import sleep

a = Account(123123, fname="Alex", lname="Andrio", ptz_offset=-11)
print(a.balance)
a.deposit(101)
print(a.balance)
a.withdraw(100)
print(a.balance)
a._deposit_interest()
print(a.balance)
a.deposit(14_000)
print(a.balance)
sleep(3)
a._deposit_interest()
print(a.balance)
a.withdraw(10_000)
print(a.balance)
a.withdraw(20_000)
print(a.balance)

for t in a.reports:
    print(t)

# print(a.balance)
b = Account(123124, fname="Alexei", lname="Andrioskyi", ptz_offset=-11)
c = Account(123125, fname="Alessio", lname="Andrini", ptz_offset=-11)
# print(Account._account_numbers)

result_a = a.generate_result_object(a.reports[1])
print(result_a.time, result_a.time_utc)

def asd(asda):
    pass

asd(asda='dsfs')
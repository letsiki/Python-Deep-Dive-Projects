import pytest
import os
import sys
sys.path.append(os.getcwd())
from src.descriptors2 import IntegerField, CharField

class Person:

    def __init__(self, f_name, l_name, age) -> None:
        self.f_name = f_name
        self.l_name = l_name
        self.age = age

    f_name = CharField(2, 15)
    l_name = CharField(2, 20)
    age = IntegerField(0, 150)

class PersonDefaultArgs:

    def __init__(self, f_name, l_name, age, lucky_int) -> None:
        self.f_name = f_name
        self.l_name = l_name
        self.age = age
        self.lucky_int = lucky_int

    f_name = CharField(max_=15)
    l_name = CharField(min_=2)
    age = IntegerField(0)
    lucky_int = IntegerField(max_=10)

def test_charfield_init():
    with pytest.raises(TypeError) as ex:
        CharField('asd', 20)
    assert str(ex.value) == 'min must be an integer value'

    with pytest.raises(TypeError) as ex:
        CharField(0, 'aa')
    assert str(ex.value) == 'max must be an integer value'

    with pytest.raises(ValueError) as ex:
        CharField(-2, 20)
    assert str(ex.value) == 'min must be a positive integer value'

    with pytest.raises(ValueError) as ex:
        CharField(0, -3)
    assert str(ex.value) == 'max must be a positive integer value'

    with pytest.raises(ValueError) as ex:
        CharField(30, 2)
    assert str(ex.value) == 'min cannot be greater than the max'

def test_intfield_init():
    with pytest.raises(TypeError) as ex:
        IntegerField('asd', -18)
    assert str(ex.value) == 'min must be an integer value'

    with pytest.raises(TypeError) as ex:
        IntegerField(-33, 'aa')
    assert str(ex.value) == 'max must be an integer value'

    with pytest.raises(ValueError) as ex:
        IntegerField(30, 2)
    assert str(ex.value) == 'min cannot be greater than the max'

@pytest.fixture
def person_instance():
    return Person('Alex', 'Andriopoulos', 42)

@pytest.fixture
def person_default_args_instance():
    return PersonDefaultArgs('John', 'Smith', 999, -9)

def test_getter(person_instance):
    assert person_instance.f_name == 'Alex'
    assert person_instance.l_name == 'Andriopoulos'
    assert person_instance.age == 42
    assert person_instance._f_name == 'Alex'
    assert person_instance._l_name == 'Andriopoulos'
    assert person_instance._age == 42    
    assert isinstance(Person.f_name, CharField) == True
    assert isinstance(Person.l_name, CharField) == True
    assert isinstance(Person.age, IntegerField) == True

def test_setter(person_instance, person_default_args_instance):
    with pytest.raises(TypeError) as ex:
        person_instance.age = 'sdf'
    assert str(ex.value) == 'age can only be an Integer'    

    with pytest.raises(ValueError) as ex:
        person_instance.age = -1
    assert str(ex.value) == 'value for age cannot be less than 0' 

    with pytest.raises(ValueError) as ex:
        person_instance.age = 180
    assert str(ex.value) == 'value for age cannot be more than 150' 

    with pytest.raises(TypeError) as ex:
        person_instance.f_name = 123
    assert str(ex.value) == 'f_name can only be a String'

    with pytest.raises(ValueError) as ex:
        person_instance.f_name = 's'
    assert str(ex.value) == 'length for f_name cannot be less than 2'  

    with pytest.raises(ValueError) as ex:
        person_instance.f_name = 'sdfaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
    assert str(ex.value) == 'length for f_name cannot be more than 15'

    with pytest.raises(TypeError) as ex:
        person_instance.l_name = 123
    assert str(ex.value) == 'l_name can only be a String'

    with pytest.raises(ValueError) as ex:
        person_instance.l_name = 's'
    assert str(ex.value) == 'length for l_name cannot be less than 2'

    with pytest.raises(ValueError) as ex:
        person_instance.l_name = 'sdfaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
    assert str(ex.value) == 'length for l_name cannot be more than 20'

    person_default_args_instance.f_name = 'asd'
    assert person_default_args_instance.f_name == 'asd'

    person_default_args_instance.l_name = 'asd'
    assert person_default_args_instance.l_name == 'asd'

    person_default_args_instance.age = 15
    assert person_default_args_instance.age == 15

    person_default_args_instance.lucky_int = -15
    assert person_default_args_instance.lucky_int == -15
    

if __name__ == '__main__':
    pytest.main(['./tests/test_1.py'])